﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/*4. Elaborar una interfaz gráfica que muestre una calculadora (utilizar
objetos de la clase Button y un objeto de la clase Label donde se
muestra el valor ingresado), tener en cuenta que solo se debe
implementar la interfaz y la carga de un valor de hasta 12 dígitos.*/
namespace Ejercicio
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.TextLength < 12) { 
            textBox1.AppendText("7");
                }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (textBox1.TextLength < 12)
            {
                textBox1.AppendText("8");
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (textBox1.TextLength < 12)
            {
                textBox1.AppendText("1");
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (textBox1.TextLength < 12)
            {
                textBox1.AppendText("2");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (textBox1.TextLength < 12)
            {
                textBox1.AppendText("3");
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (textBox1.TextLength < 12)
            {
                textBox1.AppendText("0");
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (textBox1.TextLength < 12)
            {
                textBox1.AppendText("5");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.TextLength < 12)
            {
                textBox1.AppendText("4");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox1.TextLength < 12)
            {
                textBox1.AppendText("9");
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (textBox1.TextLength < 12)
            {
                textBox1.AppendText("6");
            }
        }

        private void button16_Click(object sender, EventArgs e)
        {

        }
    }
}
