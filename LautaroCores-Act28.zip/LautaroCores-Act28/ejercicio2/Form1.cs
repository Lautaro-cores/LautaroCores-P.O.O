﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/*2. Conversor de Temperatura
● Consigna: Disponer un TextBox para el ingreso numérico y dos RadioButton:
&quot;Celsius a Fahrenheit&quot; y &quot;Fahrenheit a Celsius&quot;. Al presionar un Button, realizar la
fórmula correspondiente y mostrar el resultado en un Label.*/
namespace ejercicio2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            double temperatura = double.Parse(textBox1.Text);

            double celsius = (temperatura * 1.8) + 32;

            label1.Text = $"La temperatura en Fahrenheit es: {celsius.ToString()}";
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            double temperatura = double.Parse(textBox1.Text);

            double fahrenheit = (temperatura - 32) / 1.8;

            label1.Text = $"La temperatura en celsius es: {fahrenheit.ToString()}";
        }


    }
}
