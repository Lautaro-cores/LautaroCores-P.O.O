﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/*1. Calculadora de Promedio de Notas
● Consigna: Crear un formulario con tres TextBox para ingresar notas y un Button
&quot;Calcular&quot;. Convertir los valores con int.Parse() o double.Parse() y mostrar en una
Label el promedio. Si la nota es mayor o igual a 6, cambiar el color del texto de la
etiqueta a verde; de lo contrario, a rojo.*/
namespace ejercicio1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int Nota1 = int.Parse(textBox1.Text);
            int Nota2 = int.Parse(textBox2.Text);
            int Nota3 = int.Parse(textBox3.Text);

            int promedio = (Nota1 + Nota2 + Nota3) / 3;

            if (promedio >= 6)
            {
                label1.ForeColor = Color.Green;
            }
            else 
            {
                label1.ForeColor = Color.Red;
            }
            label1.Text = $"el Promedio de notas es: {promedio.ToString()}";
        }
    }
}
