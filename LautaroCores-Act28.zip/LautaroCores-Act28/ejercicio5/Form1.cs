﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/*5. Visor Dinámico de Imágenes (Investigación: PictureBox)
● Investigación: Investigar la clase PictureBox y sus propiedades ImageLocation y
SizeMode.
● Consigna: Cargar en un ComboBox tres opciones. Al cambiar la selección mediante
el evento SelectedIndexChanged, mostrar la imagen correspondiente dentro del
PictureBox.*/
namespace ejercicio5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = comboBox1.SelectedIndex;
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            
            
            if (index == 0)
            {
                pictureBox1.ImageLocation = @"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT_OAIomJtooKTZF6lcIJxO7P6J44r94IrehAItGiPbJg&s=10";
            }
            if (index == 1) 
            {
                pictureBox1.ImageLocation = @"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRGMXHVl9ATy2KWr7izp97ZLV-yx4oJWQ8P8roH4hWflA&s=10";
            }
            if (index == 2) 
            {
                pictureBox1.ImageLocation = @"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRm2J0JZKUCCTJpQaUOEXI-cqHny1LE3kzgQMyYm1Cd_Q&s=10";
            }
        }
    }
}
