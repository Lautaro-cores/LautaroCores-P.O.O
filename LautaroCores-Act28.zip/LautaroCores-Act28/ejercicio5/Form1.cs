﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/*5. Visor Dinámico de Imágenes (Investigación: PictureBox)
● Investigación: Investigar la clase PictureBox y sus propiedades ImageLocation y
SizeMode.
● Consigna: Cargar en un ComboBox tres opciones. Al cambiar la selección mediante
el evento SelectedIndexChanged, mostrar la imagen correspondiente dentro del
PictureBox.*/
namespace ejercicio5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = comboBox1.SelectedIndex;
            
            
            if (index == 0)
            {
                pictureBox1.ImageLocation = @"C:\Users\alumno.ET26\Downloads\images (10).jpg";
            }
            if (index == 1) 
            {
                pictureBox1.ImageLocation = @"C:\Users\alumno.ET26\Downloads\images (9).jpg";
            }
            if (index == 2) 
            {
                pictureBox1.ImageLocation = @"C:\Users\alumno.ET26\Downloads\images (11).jpg";
            }
        }
    }
}
