﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.AxHost;
/*4. Temporizador de Clics (Investigación: Timer)
● Investigación: Explicar el componente Timer (propiedades Interval, Enabled y
evento Tick) con un breve ejemplo explicativo.
● Consigna: Crear un mini-juego donde un Button cuente cuántos clics realiza el
usuario en 10 segundos. Al finalizar el tiempo mediante el Timer, deshabilitar el
botón (Enabled = false) y mostrar el puntaje acumulado en un MessageBox.Show.*/
namespace ejercicio4
{
    public partial class Form1 : Form
    {
        int clicks = 0;
        public Form1()
        {
            InitializeComponent();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            clicks = 0;
            timer1.Enabled = true;
            timer1.Interval = 10000;
            timer1.Start();
            button1.Enabled = true;
            timer1.Tick += new EventHandler(timer1_Tick);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (timer1.Enabled == true)
            {
                clicks++;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Stop();
            button1.Enabled = false;
            MessageBox.Show($"la cantidad de clicks fue de {clicks}");
        }
    }
}
