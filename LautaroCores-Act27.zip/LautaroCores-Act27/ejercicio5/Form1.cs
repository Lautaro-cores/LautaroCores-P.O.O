﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/*Actividad 5: Configuración de Suscripción
Problema:
Una aplicación ofrece distintos niveles de suscripción.
Requisitos:
● Usar un ComboBox para elegir el tipo de plan: &quot;Gratis&quot;, &quot;Básico&quot;, &quot;Premium&quot;.
● Incluir dos CheckBox para elegir servicios adicionales (por ejemplo: &quot;Soporte
técnico&quot;, &quot;Acceso anticipado&quot;).
● Al presionar el botón &quot;Guardar&quot;, se debe mostrar en un Label un resumen con el
plan y los servicios elegidos.*/
namespace ejercicio5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            label1.Text = $"Tipo de suscripcion: {comboBox1.Text}";

            if (checkBox1.Checked == true) 
            {
                label1.Text += $" + {checkBox1.Text}";
            }
            if (checkBox2.Checked == true)
            {
                label1.Text += $" + {checkBox2.Text}";
            }
        }
    }
}
