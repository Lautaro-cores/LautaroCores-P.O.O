﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/*Actividad 2: Encuesta de Preferencias de Música
Problema:
Una aplicación quiere conocer los gustos musicales de los usuarios.
Requisitos:
● Mostrar un ComboBox con 5 géneros musicales distintos.
● Incluir tres CheckBox que representen actividades relacionadas (por ejemplo:
&quot;Escuchar en vivo&quot;, &quot;Escuchar en streaming&quot;, &quot;Comprar discos&quot;).
● Al presionar un botón &quot;Mostrar Preferencias&quot;, en un Label se debe mostrar el género
seleccionado y las actividades marcadas.*/
namespace ejercicio2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label1.Text = $"{comboBox1.Text}: ";

            if (checkBox1.Checked == true) 
            {
                label1.Text += "Escuchar en vivo,";
            }
            if (checkBox2.Checked == true)
            {
                label1.Text += "Escuchar en Streaming,";
            }
            if (checkBox3.Checked == true)
            {
                label1.Text += "Comprar discos,";
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
