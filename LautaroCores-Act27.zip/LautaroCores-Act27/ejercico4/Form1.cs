﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ejercico4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
            {
                label3.Text = $"Opinión recibida: {textBox1.Text} - Recomendacion: {radioButton1.Text}";
            }
            if (radioButton2.Checked == true)
            {
                label3.Text = $"Opinión recibida: {textBox1.Text} - Recomendacion: {radioButton2.Text}";
            }
        }
    }
}
