﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio4
{
    internal class Program
    {
        static void Main(string[] args)
        { 
            //4.Se cargan por teclado tres números distintos. Mostrar por pantalla el mayor de ellos.
            
            int num1, num2, num3;
            string linea;

            Console.Write("ingrese un numero: ");
            linea = Console.ReadLine();
            num1 = int.Parse(linea);

            Console.Write("ingrese un segundo numero: ");
            linea = Console.ReadLine();
            num2 = int.Parse(linea);

            Console.Write("ingrese un tercer numero: ");
            linea = Console.ReadLine();
            num3 = int.Parse(linea);


            if (num1 > num2 && num1 > num3)
            {
                Console.Write("el mas grande es " + num1);
            }
            else
            {
                if (num2 > num3 && num2 > num1)
                {
                    Console.Write("el mas grande es " + num2);
                }
                else
                {
                    Console.Write("el mas grande es " + num3);
                }
                {

                }

            }
            Console.ReadKey();
        }
    }
}

