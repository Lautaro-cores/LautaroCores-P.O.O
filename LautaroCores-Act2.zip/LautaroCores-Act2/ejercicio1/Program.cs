﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //1. Realizar un programa que lea por teclado dos números, si el primero es mayor al segundo informar su suma y diferencia, en caso contrario informar el producto y la división del primero respecto al segundo.

            int num1, num2, resultado, resultado2;
            string linea;

            Console.Write("ingrese un numero: ");
            linea = Console.ReadLine();
            num1 = int.Parse(linea);

            Console.Write("ingrese un segundo numero: ");
            linea = Console.ReadLine();
            num2 = int.Parse(linea);

            if ( num1 > num2)
            {
                resultado = num1 + num2;
                resultado2 = num1 - num2;
                Console.WriteLine("su suma: " + resultado); 
                Console.WriteLine("su diferencia: " + resultado2);
            }
            else
            { if ( num1 < num2)
                {
                    resultado = num1 * num2;
                    resultado2 = num1 / num2;
                    Console.WriteLine("su producto: " + resultado);
                    Console.WriteLine("su division del del primero respecto al segundo: " + resultado2);
                }
                    
            }
           
            Console.ReadKey();
        }
    }
}
