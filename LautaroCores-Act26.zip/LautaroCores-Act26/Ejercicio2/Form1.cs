﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/*2. Permitir el ingreso de dos números en controles de tipo TextBox y mediante
dos controles de tipo RadioButton permitir seleccionar si queremos sumarlos o
restarlos. Al presionar un botón mostrar en el título del Form el resultado de la
operación.*/
namespace Ejercicio2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

            Text = "";

                int Numero1 = int.Parse(textBox1.Text);
                int Numero2 = int.Parse(textBox2.Text);

                Text = (Numero1 - Numero2).ToString();
         
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            Text = "";
 
                int Numero1 = int.Parse(textBox1.Text);
                int Numero2 = int.Parse(textBox2.Text);

                Text = (Numero1 + Numero2).ToString();
         
        }
    }
}
