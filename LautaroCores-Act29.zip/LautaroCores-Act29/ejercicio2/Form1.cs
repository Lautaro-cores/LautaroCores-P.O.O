﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ejercicio2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int rojo = Convert.ToInt32(numericUpDown1.Value);
            int verde = Convert.ToInt32(numericUpDown2.Value);
            int azul = Convert.ToInt32(numericUpDown3.Value);

            this.BackColor = Color.FromArgb(rojo,verde,azul);
        }
    }
    }
    
