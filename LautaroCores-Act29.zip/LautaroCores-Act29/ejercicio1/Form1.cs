﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ejercicio1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int sumatotal = 0;

            if (checkBox1.Checked == true)
            {
                sumatotal += 2867;
            }
            if (checkBox2.Checked == true)
            {
                sumatotal += 5870;
            }
            if (checkBox3.Checked == true)
            {
                sumatotal += 2499;
            }

            label1.Text = $"La suma total de la compra es de {sumatotal}";
        }
    }
}
