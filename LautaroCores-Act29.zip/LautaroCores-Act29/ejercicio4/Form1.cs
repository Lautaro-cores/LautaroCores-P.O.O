﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ejercicio4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var fechaNac = dateTimePicker1.Value;
            var añostotal = dateTimePicker1.Value.AddYears(-DateTime.Now.Year);

            label1.Text = $"los años calculados serian {añostotal}";
        }
    }
}
